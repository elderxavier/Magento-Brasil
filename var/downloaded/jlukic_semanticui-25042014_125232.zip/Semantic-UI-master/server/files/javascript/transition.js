semantic.transition = {};

// ready event
semantic.transition.ready = function() {

  // selector cache
  var 
    handler
  ;
};


// attach ready event
$(document)
  .ready(semantic.transition.ready)
;